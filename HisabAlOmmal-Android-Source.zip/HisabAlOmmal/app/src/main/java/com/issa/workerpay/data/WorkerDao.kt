package com.issa.workerpay.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface WorkerDao {
    @Query("SELECT * FROM workers ORDER BY active DESC, name COLLATE NOCASE") fun workers(): Flow<List<Worker>>
    @Query("SELECT * FROM workers WHERE id = :id") fun worker(id: Long): Flow<Worker?>
    @Insert suspend fun addWorker(worker: Worker): Long
    @Update suspend fun updateWorker(worker: Worker)
    @Delete suspend fun deleteWorker(worker: Worker)

    @Query("SELECT * FROM work_days WHERE workerId = :workerId ORDER BY date DESC") fun workDays(workerId: Long): Flow<List<WorkDay>>
    @Query("SELECT * FROM work_days WHERE workerId = :workerId AND date BETWEEN :from AND :to ORDER BY date") fun workDaysBetween(workerId: Long, from: String, to: String): Flow<List<WorkDay>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putWorkDay(day: WorkDay)
    @Delete suspend fun deleteWorkDay(day: WorkDay)

    @Query("SELECT * FROM transactions WHERE workerId = :workerId ORDER BY date DESC, id DESC") fun transactions(workerId: Long): Flow<List<WorkerTransaction>>
    @Insert suspend fun addTransaction(transaction: WorkerTransaction)
    @Delete suspend fun deleteTransaction(transaction: WorkerTransaction)

    @Query("SELECT COALESCE(SUM(days * rate),0) FROM work_days WHERE workerId = :id") fun earned(id: Long): Flow<Long>
    @Query("SELECT COALESCE(SUM(CASE WHEN type='PAYMENT' THEN amount ELSE 0 END),0) FROM transactions WHERE workerId = :id") fun paid(id: Long): Flow<Long>
    @Query("SELECT COALESCE(SUM(CASE WHEN type='ADVANCE' THEN amount ELSE 0 END),0) FROM transactions WHERE workerId = :id") fun advances(id: Long): Flow<Long>
    @Query("SELECT COALESCE(SUM(CASE WHEN type='DEDUCTION' THEN amount ELSE 0 END),0) FROM transactions WHERE workerId = :id") fun deductions(id: Long): Flow<Long>
    @Query("SELECT COALESCE(SUM(CASE WHEN type='BONUS' THEN amount ELSE 0 END),0) FROM transactions WHERE workerId = :id") fun bonuses(id: Long): Flow<Long>
}
