package com.issa.workerpay.data

import androidx.room.*

@Entity(tableName = "workers")
data class Worker(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val dailyRate: Long,
    val phone: String = "",
    val active: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "work_days", foreignKeys = [ForeignKey(entity = Worker::class, parentColumns = ["id"], childColumns = ["workerId"], onDelete = ForeignKey.CASCADE)], indices = [Index("workerId"), Index(value = ["workerId", "date"], unique = true)])
data class WorkDay(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val workerId: Long,
    val date: String, // yyyy-MM-dd
    val days: Double = 1.0,
    val rate: Long,
    val note: String = ""
) {
    val amount: Long get() = (days * rate).toLong()
}

@Entity(tableName = "transactions", foreignKeys = [ForeignKey(entity = Worker::class, parentColumns = ["id"], childColumns = ["workerId"], onDelete = ForeignKey.CASCADE)], indices = [Index("workerId"), Index("date")])
data class WorkerTransaction(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val workerId: Long,
    val date: String,
    val amount: Long,
    val type: String, // ADVANCE, PAYMENT, DEDUCTION, BONUS
    val note: String = ""
)

data class WorkerSummary(
    @Embedded val worker: Worker,
    @ColumnInfo(name = "earned") val earned: Long,
    @ColumnInfo(name = "paid") val paid: Long,
    @ColumnInfo(name = "advances") val advances: Long,
    @ColumnInfo(name = "deductions") val deductions: Long,
    @ColumnInfo(name = "bonuses") val bonuses: Long
) {
    val balance: Long get() = earned + bonuses - paid - advances - deductions
}
