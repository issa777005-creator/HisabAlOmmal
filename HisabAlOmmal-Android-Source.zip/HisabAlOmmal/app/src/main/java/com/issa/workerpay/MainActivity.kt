package com.issa.workerpay

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.WorkHistory
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.room.withTransaction
import com.issa.workerpay.data.*
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dao = AppDatabase.get(this).workerDao()
        setContent { MaterialTheme(colorScheme = lightColorScheme(primary = androidx.compose.ui.graphics.Color(0xFF176B55), secondary = androidx.compose.ui.graphics.Color(0xFFB7791F))) { WorkerApp(dao) } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun WorkerApp(dao: WorkerDao) {
    val workers by dao.workers().collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    var showAdd by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf<Worker?>(null) }
    var query by remember { mutableStateOf("") }
    val filtered = workers.filter { it.name.contains(query, true) }
    Scaffold(
        topBar = { TopAppBar(title = { Column { Text("حساب العمال", fontWeight = FontWeight.Bold); Text("إدارة اليوميات والمستحقات", style = MaterialTheme.typography.labelSmall) } }) },
        floatingActionButton = { ExtendedFloatingActionButton(onClick = { showAdd = true }, icon = { Icon(Icons.Default.Add, null) }, text = { Text("إضافة عامل") }) }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp)) {
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MetricCard("عدد العمال", workers.size.toString(), Icons.Default.Groups, Modifier.weight(1f))
                MetricCard("النشطون", workers.count { it.active }.toString(), Icons.Default.WorkHistory, Modifier.weight(1f))
            }
            Spacer(Modifier.height(18.dp))
            OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth(), label = { Text("بحث عن عامل") }, singleLine = true)
            Spacer(Modifier.height(12.dp))
            Text("قائمة العمال", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            if (filtered.isEmpty()) {
                Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                    Text(if (workers.isEmpty()) "ابدأ بإضافة أول عامل إلى السجل" else "لا توجد نتائج مطابقة", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp), contentPadding = PaddingValues(bottom = 90.dp)) {
                items(filtered, key = { it.id }) { worker ->
                    WorkerCard(worker, dao) { selected = worker }
                }
            }
        }
    }
    if (showAdd) AddWorkerDialog(onDismiss = { showAdd = false }) { name, rate, phone ->
        scope.launch { dao.addWorker(Worker(name = name, dailyRate = rate, phone = phone)) }
        showAdd = false
    }
    selected?.let { worker -> WorkerDetailDialog(worker, dao, onDismiss = { selected = null }) }
}

@Composable
private fun MetricCard(label: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier) {
    Card(modifier, shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary)
            Column { Text(label, style = MaterialTheme.typography.labelMedium); Text(value, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }
        }
    }
}

@Composable
private fun WorkerCard(worker: Worker, dao: WorkerDao, onClick: () -> Unit) {
    val earned by dao.earned(worker.id).collectAsState(initial = 0L)
    val paid by dao.paid(worker.id).collectAsState(initial = 0L)
    val advances by dao.advances(worker.id).collectAsState(initial = 0L)
    val deductions by dao.deductions(worker.id).collectAsState(initial = 0L)
    val bonuses by dao.bonuses(worker.id).collectAsState(initial = 0L)
    val balance = earned + bonuses - paid - advances - deductions
    Card(onClick = onClick, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(15.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) { Text(worker.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold); Text("اليومية: ${money(worker.dailyRate)} د.ع", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                AssistChip(onClick = onClick, label = { Text(if (worker.active) "نشط" else "متوقف") })
            }
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column { Text("الأجر المكتسب", style = MaterialTheme.typography.labelSmall); Text(money(earned + bonuses), fontWeight = FontWeight.SemiBold) }
                Column(horizontalAlignment = Alignment.End) { Text("المتبقي", style = MaterialTheme.typography.labelSmall); Text(money(balance), color = if (balance < 0) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold) }
            }
        }
    }
}

@Composable
private fun AddWorkerDialog(onDismiss: () -> Unit, onSave: (String, Long, String) -> Unit) {
    var name by remember { mutableStateOf("") }; var rate by remember { mutableStateOf("") }; var phone by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("إضافة عامل") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(name, { name = it }, label = { Text("اسم العامل") }, singleLine = true)
            OutlinedTextField(rate, { rate = it.filter(Char::isDigit) }, label = { Text("الأجر اليومي بالدينار") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
            OutlinedTextField(phone, { phone = it }, label = { Text("رقم الهاتف (اختياري)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), singleLine = true)
        }
    }, confirmButton = { Button(enabled = name.isNotBlank() && (rate.toLongOrNull() ?: 0) > 0, onClick = { onSave(name.trim(), rate.toLong(), phone.trim()) }) { Text("حفظ العامل") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } })
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun WorkerDetailDialog(worker: Worker, dao: WorkerDao, onDismiss: () -> Unit) {
    val scope = rememberCoroutineScope()
    val days by dao.workDays(worker.id).collectAsState(initial = emptyList())
    val txs by dao.transactions(worker.id).collectAsState(initial = emptyList())
    val earned = days.sumOf { it.amount }
    val paid = txs.filter { it.type == "PAYMENT" }.sumOf { it.amount }
    val advances = txs.filter { it.type == "ADVANCE" }.sumOf { it.amount }
    val deductions = txs.filter { it.type == "DEDUCTION" }.sumOf { it.amount }
    val bonuses = txs.filter { it.type == "BONUS" }.sumOf { it.amount }
    val balance = earned + bonuses - paid - advances - deductions
    var showWork by remember { mutableStateOf(false) }
    var showTx by remember { mutableStateOf(false) }
    var tab by remember { mutableIntStateOf(0) }
    AlertDialog(
        onDismissRequest = onDismiss,
        modifier = Modifier.fillMaxWidth(),
        title = { Column { Text(worker.name, fontWeight = FontWeight.Bold); Text("اليومية ${money(worker.dailyRate)} د.ع", style = MaterialTheme.typography.labelMedium) } },
        text = {
            Column(Modifier.fillMaxWidth()) {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                    Column(Modifier.fillMaxWidth().padding(12.dp)) {
                        Text("المستحق الحالي", style = MaterialTheme.typography.labelMedium)
                        Text("${money(balance)} د.ع", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                        Text("أجور ${money(earned)}  •  سلف ${money(advances)}  •  مدفوع ${money(paid)}", style = MaterialTheme.typography.labelSmall)
                    }
                }
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Button(onClick = { showWork = true }, modifier = Modifier.weight(1f)) { Text("إضافة أيام") }
                    OutlinedButton(onClick = { showTx = true }, modifier = Modifier.weight(1f)) { Text("سلفة / دفعة") }
                }
                Spacer(Modifier.height(8.dp))
                TabRow(selectedTabIndex = tab) { Tab(tab == 0, { tab = 0 }, text = { Text("أيام العمل (${days.size})") }); Tab(tab == 1, { tab = 1 }, text = { Text("الحركات (${txs.size})") }) }
                if (tab == 0) {
                    if (days.isEmpty()) Text("لا توجد أيام مسجلة بعد", Modifier.padding(12.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
                    else LazyColumn(Modifier.heightIn(max = 260.dp)) { items(days, key = { it.id }) { d ->
                        ListItem(headlineContent = { Text(d.date) }, supportingContent = { Text("${d.days} يوم × ${money(d.rate)}") }, trailingContent = { Row(verticalAlignment = Alignment.CenterVertically) { Text(money(d.amount), fontWeight = FontWeight.SemiBold); IconButton(onClick = { scope.launch { dao.deleteWorkDay(d) } }) { Text("×") } } })
                    } }
                } else {
                    if (txs.isEmpty()) Text("لا توجد حركات مالية", Modifier.padding(12.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
                    else LazyColumn(Modifier.heightIn(max = 260.dp)) { items(txs, key = { it.id }) { t ->
                        val label = when(t.type) { "ADVANCE" -> "سلفة"; "PAYMENT" -> "دفعة راتب"; "DEDUCTION" -> "خصم"; else -> "مكافأة" }
                        ListItem(headlineContent = { Text(label) }, supportingContent = { Text("${t.date} ${if (t.note.isNotBlank()) "• ${t.note}" else ""}") }, trailingContent = { Row(verticalAlignment = Alignment.CenterVertically) { Text(money(t.amount)); IconButton(onClick = { scope.launch { dao.deleteTransaction(t) } }) { Text("×") } } })
                    } }
                }
                Spacer(Modifier.height(6.dp))
                Text("المعادلة: الأجور + المكافآت − الدفعات − السلف − الخصميات", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("إغلاق") } }
    )
    if (showWork) AddWorkDialog(worker, onDismiss = { showWork = false }) { dateList, units, note ->
        scope.launch {
            dateList.forEach { date -> dao.putWorkDay(WorkDay(workerId = worker.id, date = date, days = units, rate = worker.dailyRate, note = note)) }
        }
        showWork = false
    }
    if (showTx) AddTransactionDialog(worker, onDismiss = { showTx = false }) { date, amount, type, note ->
        scope.launch { dao.addTransaction(WorkerTransaction(workerId = worker.id, date = date, amount = amount, type = type, note = note)) }
        showTx = false
    }
}

@Composable
private fun AddWorkDialog(worker: Worker, onDismiss: () -> Unit, onSave: (List<String>, Double, String) -> Unit) {
    var dates by remember { mutableStateOf(LocalDate.now().format(DateTimeFormatter.ISO_DATE)) }
    var units by remember { mutableStateOf("1") }
    var note by remember { mutableStateOf("") }
    val parsed = dates.split(',', '\n', ' ').map { it.trim() }.filter { it.isNotBlank() }.distinct().filter { runCatching { LocalDate.parse(it) }.isSuccess }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("إضافة أيام عمل") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("اكتب تاريخاً واحداً أو عدة تواريخ مفصولة بفاصلة. الصيغة: سنة-شهر-يوم", style = MaterialTheme.typography.bodySmall)
            OutlinedTextField(dates, { dates = it }, label = { Text("التواريخ") }, minLines = 2)
            OutlinedTextField(units, { units = it }, label = { Text("عدد الأيام لكل تاريخ (مثلاً 1 أو 0.5)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
            OutlinedTextField(note, { note = it }, label = { Text("ملاحظة (اختياري)") }, singleLine = true)
            Text("سيتم تسجيل ${parsed.size} تاريخ • اليومية ${money(worker.dailyRate)} د.ع", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
        }
    }, confirmButton = { Button(enabled = parsed.isNotEmpty() && (units.toDoubleOrNull() ?: 0.0) > 0, onClick = { onSave(parsed, units.toDouble(), note.trim()) }) { Text("حفظ الأيام") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } })
}

@Composable
private fun AddTransactionDialog(worker: Worker, onDismiss: () -> Unit, onSave: (String, Long, String, String) -> Unit) {
    var date by remember { mutableStateOf(LocalDate.now().toString()) }; var amount by remember { mutableStateOf("") }; var type by remember { mutableStateOf("ADVANCE") }; var note by remember { mutableStateOf("") }
    val types = listOf("ADVANCE" to "سلفة", "PAYMENT" to "دفعة راتب", "DEDUCTION" to "خصم", "BONUS" to "مكافأة")
    AlertDialog(onDismissRequest = onDismiss, title = { Text("تسجيل حركة مالية") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("العامل: ${worker.name}", style = MaterialTheme.typography.labelMedium)
            OutlinedTextField(date, { date = it }, label = { Text("التاريخ yyyy-MM-dd") }, singleLine = true)
            OutlinedTextField(amount, { amount = it.filter(Char::isDigit) }, label = { Text("المبلغ بالدينار") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
            types.forEach { (key, label) -> Row(verticalAlignment = Alignment.CenterVertically) { RadioButton(type == key, { type = key }); Text(label) } }
            OutlinedTextField(note, { note = it }, label = { Text("ملاحظة (اختياري)") }, singleLine = true)
        }
    }, confirmButton = { Button(enabled = (amount.toLongOrNull() ?: 0) > 0 && runCatching { LocalDate.parse(date) }.isSuccess, onClick = { onSave(date, amount.toLong(), type, note.trim()) }) { Text("حفظ الحركة") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } })
}

private fun money(value: Long): String = String.format(Locale.US, "%,d", value)
